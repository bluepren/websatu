import Navbar from "./components/Navbar";
import Ticker from "./components/Ticker";
import Hero from "./components/Hero";
import About from "./components/About";
import Performance from "./components/Performance";
import Strategy from "./components/Strategy";
import TrackRecord from "./components/TrackRecord";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-[#07090d] text-white selection:bg-[#00e6a8]/30">
      <Navbar />
      <main>
        <Hero />
        <Ticker />
        <About />
        <Performance />
        <Strategy />
        <TrackRecord />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
