export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-10">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#00e6a8] to-[#19f0c0] grid place-items-center text-black font-bold text-sm">
            A
          </div>
          <span className="font-semibold">Arman<span className="text-[#00e6a8]">.</span>Wijaya</span>
        </div>
        <p className="text-sm text-gray-500">
          © 2026 Wijaya Capital. Built with discipline & data.
        </p>
        <div className="flex gap-6 text-sm text-gray-500">
          <a href="#" className="hover:text-white transition">Privacy</a>
          <a href="#" className="hover:text-white transition">Terms</a>
          <a href="#" className="hover:text-white transition">Risk Disclosure</a>
        </div>
      </div>
    </footer>
  );
}
