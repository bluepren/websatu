import { useEffect, useState } from "react";

const links = [
  { href: "#about", label: "Tentang" },
  { href: "#performance", label: "Performa" },
  { href: "#strategy", label: "Strategi" },
  { href: "#track", label: "Track Record" },
  { href: "#testimoni", label: "Testimoni" },
  { href: "#kontak", label: "Kontak" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all ${
        scrolled
          ? "backdrop-blur-xl bg-[#07090d]/70 border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2 group">
          <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-[#00e6a8] to-[#19f0c0] grid place-items-center text-black font-bold">
            A
            <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#00e6a8] pulse-dot text-[#00e6a8]" />
          </div>
          <span className="font-semibold tracking-tight">
            Arman<span className="text-[#00e6a8]">.</span>Wijaya
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-gray-300 hover:text-white transition relative group"
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#00e6a8] group-hover:w-full transition-all" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#kontak"
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#00e6a8] hover:bg-[#19f0c0] text-black text-sm font-semibold transition"
          >
            Konsultasi Gratis
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M13 5l7 7-7 7" />
            </svg>
          </a>
          <button
            className="lg:hidden w-10 h-10 grid place-items-center rounded-lg border border-white/10"
            onClick={() => setOpen((v) => !v)}
            aria-label="menu"
          >
            <div className="space-y-1.5">
              <span className={`block h-px w-5 bg-white transition ${open ? "translate-y-1.5 rotate-45" : ""}`} />
              <span className={`block h-px w-5 bg-white transition ${open ? "opacity-0" : ""}`} />
              <span className={`block h-px w-5 bg-white transition ${open ? "-translate-y-1.5 -rotate-45" : ""}`} />
            </div>
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden border-t border-white/5 bg-[#07090d]/95 backdrop-blur-xl">
          <div className="px-6 py-4 flex flex-col gap-3">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="py-2 text-gray-300"
              >
                {l.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
