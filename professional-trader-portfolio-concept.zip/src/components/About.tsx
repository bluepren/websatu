export default function About() {
  return (
    <section id="about" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <SectionLabel>01 — Tentang</SectionLabel>
            <h2 className="mt-4 text-4xl lg:text-5xl font-bold leading-tight">
              Profesional yang membaca pasar, bukan menebak.
            </h2>
          </div>
          <div className="lg:col-span-7 space-y-6 text-gray-400 leading-relaxed">
            <p>
              Karir saya dimulai di meja perdagangan sebuah prop firm di Singapura tahun 2017,
              sebelum akhirnya membangun strategi trading independen yang berfokus pada
              <span className="text-white"> price action, smart money concept, dan analisis intermarket</span>.
            </p>
            <p>
              Saya percaya bahwa trading bukan tentang prediksi, melainkan
              <span className="text-white"> probabilitas, eksekusi disiplin, dan pengelolaan risiko</span>.
              Setiap entry didasari oleh confluence multi-timeframe dan validasi data on-chain
              maupun makroekonomi.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 pt-4">
              {credentials.map((c) => (
                <div key={c.title} className="glass rounded-xl p-5 hover:border-white/20 transition">
                  <div className="w-10 h-10 rounded-lg bg-[#00e6a8]/10 grid place-items-center text-[#00e6a8] mb-3">
                    {c.icon}
                  </div>
                  <div className="font-semibold text-white">{c.title}</div>
                  <div className="text-sm text-gray-500 mt-1">{c.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 text-xs font-mono text-[#00e6a8] uppercase tracking-[0.2em]">
      <span className="w-8 h-px bg-[#00e6a8]" />
      {children}
    </div>
  );
}

const credentials = [
  {
    title: "CMT Level III",
    desc: "Chartered Market Technician — analisa teknikal lanjutan tersertifikasi.",
    icon: <Icon path="M12 2 4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z" />,
  },
  {
    title: "8+ Tahun Aktif",
    desc: "Pengalaman live trading di siklus bull, bear, dan sideways market.",
    icon: <Icon path="M12 8v4l3 2M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />,
  },
  {
    title: "Multi-Asset",
    desc: "Forex major, indeks, komoditas, dan crypto top market cap.",
    icon: <Icon path="M3 3v18h18M7 14l4-4 4 4 5-5" />,
  },
  {
    title: "Risk First",
    desc: "Maksimal risiko per trade 1%, drawdown bulanan dijaga di bawah 8%.",
    icon: <Icon path="M12 9v4m0 4h.01M10.29 3.86 1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />,
  },
];

function Icon({ path }: { path: string }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d={path} />
    </svg>
  );
}
